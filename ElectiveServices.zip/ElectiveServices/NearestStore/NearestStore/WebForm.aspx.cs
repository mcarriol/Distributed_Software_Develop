﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Xml;
using System.Web.Script.Serialization;
//using System.Net.Http;

namespace NearestStore
{
    public partial class WebForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string url = @"http://webstrar12.fulton.asu.edu/page8/Service1.svc/NearbyStores?ZipCode=" + TextBox2.Text + "&StoreName=" + TextBox1.Text;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream responseStream = response.GetResponseStream();

            StreamReader reader = new StreamReader(responseStream);

            string answer = reader.ReadToEnd();



            Label1.Text = answer;

        }
    }
}