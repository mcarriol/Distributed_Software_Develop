﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using System.Web.Script.Serialization;
//using System.Net; 
using Newtonsoft.Json;

namespace NearestStore
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string nearby(string zipcode, string storename)
        {
            string url = @"https://maps.googleapis.com/maps/api/geocode/json?address=" + zipcode + "&key=AIzaSyDi8z18vc3qHM_quyEectPguSrwhytmHLI";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();
            ZipRootObject getobject = JsonConvert.DeserializeObject<ZipRootObject>(responsereader);
            string longlat = getobject.results[0].geometry.location.lat.ToString() + ","
                                 + getobject.results[0].geometry.location.lng.ToString();



            string url2 = @"  https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=" + storename + "&inputtype=textquery&fields=formatted_address,name&locationbias=circle:2000@" + longlat + "&key=AIzaSyDi8z18vc3qHM_quyEectPguSrwhytmHLI";
            HttpWebRequest request2 = (HttpWebRequest)WebRequest.Create(url2);
            WebResponse response2 = request2.GetResponse();
            Stream dataStream2 = response2.GetResponseStream();
            StreamReader sreader2 = new StreamReader(dataStream2);
            string responsereader2 = sreader2.ReadToEnd();
            response2.Close();
            StoreRootObject store = JsonConvert.DeserializeObject<StoreRootObject>(responsereader2);
            return (store.candidates[0].formatted_address);
            //return string.Format("You entered: {0}", value);
        }

        public class ZipRootObject
        {
            public Result[] results { get; set; }
            public string status { get; set; }

            public class Result
            {
                public Geometry geometry { get; set; }
                public class Geometry
                {
                    public Location location { get; set; }
                    public class Location
                    {

                        public float lat { get; set; }
                        public float lng { get; set; }

                    }
                }
            }
        }

        public class StoreRootObject
        {

            public Candidate[] candidates { get; set; }
            public string status { get; set; }

            public class Candidate
            {
                public string formatted_address { get; set; }
                public string name { get; set; }

            }


        }
    
}
}
