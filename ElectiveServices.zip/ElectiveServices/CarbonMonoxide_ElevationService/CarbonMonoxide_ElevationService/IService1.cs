﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CarbonMonoxide_ElevationService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "CarbonMonoxide?longitude={longit}&latitude={lat}")]
        string Carbon(string longit, string lat);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "Elevation?longitude={longit}&latitude={lat}")]
        string GetElevation(string longit, string lat);
        // TODO: Add your service operations here
    }


    
}
