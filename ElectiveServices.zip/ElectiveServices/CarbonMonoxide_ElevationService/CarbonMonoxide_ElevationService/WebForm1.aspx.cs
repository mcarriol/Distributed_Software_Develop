﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Xml;
using System.Web.Script.Serialization;
//using System.Net.Http;

namespace CarbonMonoxide_ElevationService
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string url = @"http://webstrar12.fulton.asu.edu/page9/Service1.svc/CarbonMonoxide?longitude=" + TextBox1.Text + "&latitude=" + TextBox2.Text;


            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream responseStream = response.GetResponseStream();

            StreamReader reader = new StreamReader(responseStream);

            string answer = reader.ReadToEnd();



            Label1.Text = answer;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string url = @"http://webstrar12.fulton.asu.edu/page9/Service1.svc/Elevation?longitude=" + TextBox4.Text + "&latitude=" + TextBox5.Text;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream responseStream = response.GetResponseStream();

            StreamReader reader = new StreamReader(responseStream);

            string answer = reader.ReadToEnd();



            Label2.Text = answer;
        }
    }
}