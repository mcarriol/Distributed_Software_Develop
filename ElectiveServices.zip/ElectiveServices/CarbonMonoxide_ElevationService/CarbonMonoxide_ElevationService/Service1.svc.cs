﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

namespace CarbonMonoxide_ElevationService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string Carbon(string longit, string lat)
        {
            //string api = "0a5b1ca5c3816c18d37bdce8ffb4ab0e";
            string url = @"http://api.openweathermap.org/pollution/v1/co/" + lat + "," + longit + "/current.json?appid=0a5b1ca5c3816c18d37bdce8ffb4ab0e";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();

            //Display min and max carbon monoxide volume mixing ratio
            string answer = "";
            double min = -1;
            double max = -1;

            try
            {



                RootObject carbonObject = JsonConvert.DeserializeObject<RootObject>(responsereader);



                foreach (var item in carbonObject.data)
                {
                    // Console.WriteLine(item.value);
                    if (min == -1)
                    {
                        min = item.value;
                        max = item.value;
                    }
                    else if (item.value < min)
                    {
                        min = item.value;
                    }
                    else if (item.value > max)
                    {

                        max = item.value;
                    }


                }


                answer = "Maximum Volume: " + max.ToString() + "  Minimum Volume: " + min.ToString();


            }
            catch
            {
                answer = "no data available for inputs";

            }

            return answer;
        }
        public class RootObject
        {


            public string time { get; set; }
            public Location location { get; set; }
            public List<Data> data { get; set; }

        }

        public class Location
        {
            public double latitude { get; set; }
            public double longitude { get; set; }

        }
        public class Data
        {
            public double precision { get; set; }
            public double pressure { get; set; }
            public double value { get; set; }
        }


        public string GetElevation(string longit, string lat)
        {
            string url = @"https://maps.googleapis.com/maps/api/elevation/json?locations=" + lat + "," + longit + "&key=AIzaSyDi8z18vc3qHM_quyEectPguSrwhytmHLI";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();
            ElevationRootObject getobject = JsonConvert.DeserializeObject<ElevationRootObject>(responsereader);
            return getobject.results[0].elevation;

        }


        public class ElevationRootObject
        {

            public Result[] results { get; set; }
            public string status { get; set; }

            public class Result
            {
                public string elevation { get; set; }
                public Location location { get; set; }
                public float resolution { get; set; }
                public class Location
                {
                    public string lat { get; set; }
                    public string lng { get; set; }
                }
            }
        }


    }
}
